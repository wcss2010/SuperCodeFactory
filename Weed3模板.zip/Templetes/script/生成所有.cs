        using System.Text;
		using System.IO;
        
		/// <summary>
        /// 生成代码
        /// </summary>
        /// <param name="dbType">数据库类型</param>
		/// <param name="namespaceStr">命名空间</param>
		/// <param name="classBefore">类名前缀</param>
		/// <param name="classAfter">类名后缀</param>			
        /// <param name="outputDir">输出路径</param>
        /// <param name="connectionUrl">连接字符串</param>
        /// <param name="tables">表名(字典中Key为表名，Value为表格列信息)(string[]的长度为2，第一个为字段名称，第二个为字段类型)</param>
        /// <returns>返回提示信息,成功为ok</returns>
        string make(string dbType,string namespaceStr,string classBefore,string classAfter,string outputDir, string connectionUrl, System.Collections.Generic.Dictionary<string, System.Collections.Generic.List<string[]>> tables)
        {
			//目标路径
			string destClassesPath = Path.Combine(outputDir,"Classes");
			
			//创建目录
			try{
			  Directory.CreateDirectory(destClassesPath);
			}catch(Exception ex){}
			
			//生成连接管理器
			makeConnectionManager(namespaceStr,destClassesPath);
			
			//生成实体类接口
			makeIEntity(namespaceStr,destClassesPath);
			
			//生成实体
			foreach(System.Collections.Generic.KeyValuePair<string,System.Collections.Generic.List<string[]>> kvp in tables)
			{
				//生成表格代码
				string code = makeTable(dbType,namespaceStr,classBefore,classAfter,string.Empty,kvp.Key,kvp.Value);
				
				//写文件
				File.WriteAllText(Path.Combine(destClassesPath,classBefore + kvp.Key + classAfter + ".cs"),code);
			}
			
			//返回结果
			StringBuilder sb = new StringBuilder();
			sb.Append("生成完成");
            return sb.ToString();
        }
		
		/// <summary>
        /// 生成实体类基类
        /// </summary>
		static void makeIEntity(string namespaceStr,string destClassesPath)
		{
			StringBuilder sb = new StringBuilder();
			sb.Append("using System;\n");
			sb.Append("using System.Collections.Generic;\n");
			sb.Append("using System.Text;\n");
			sb.Append("using Noear.Weed;\n");
			sb.Append("\n");
			sb.Append("namespace ").Append(namespaceStr).Append(" \n");
			sb.Append("{\n");
			sb.Append("    /// <summary>\n");
			sb.Append("    /// 数据实体抽象类\n");
			sb.Append("    /// </summary>\n");
			sb.Append("    public abstract class IEntity : IBinder\n");
			sb.Append("    {\n");
			sb.Append("        /// <summary>\n");
			sb.Append("        /// 将数据复制到\n");
			sb.Append("        /// </summary>\n");
			sb.Append("        /// <param name=\"query\"></param>\n");
			sb.Append("        /// <returns></returns>\n");
			sb.Append("        public abstract Noear.Weed.DbTableQuery copyTo(Noear.Weed.DbTableQuery query);\n");
			sb.Append("\n");
			sb.Append("        /// <summary>\n");
			sb.Append("        /// 数据绑定\n");
			sb.Append("        /// </summary>\n");
			sb.Append("        /// <param name=\"source\"></param>\n");
			sb.Append("        public abstract void bind(GetHandlerEx source);\n");
			sb.Append("\n");
			sb.Append("        public virtual IBinder clone()\n");
			sb.Append("        {\n");
			sb.Append("            return (IBinder)this.MemberwiseClone();\n");
			sb.Append("        }\n");
			sb.Append("    }\n");
			sb.Append("}\n");
			
			File.WriteAllText(Path.Combine(destClassesPath,"IEntity.cs"),sb.ToString());
		}
		
	    /// <summary>
        /// 生成连接管理器
        /// </summary>
		static void makeConnectionManager(string namespaceStr,string destClassesPath)
		{
			StringBuilder sb = new StringBuilder();
			
			//生成连接管理器
			sb.Append("using System; \n");
			sb.Append("using System.Collections.Generic; \n");
			sb.Append("using System.Text; \n");
			sb.Append("using Noear.Weed; \n");
			sb.Append(" \n");
			sb.Append("namespace ").Append(namespaceStr).Append(" \n");
			sb.Append("{ \n");
			sb.Append("    public class ConnectionManager \n");
			sb.Append("    { \n");
			sb.Append("        private static System.Data.Common.DbProviderFactory factory = null; \n");
			sb.Append(" \n");
			sb.Append("        /// <summary> \n");
			sb.Append("        /// 数据库上下文 \n");
			sb.Append("        /// </summary> \n");
			sb.Append("        public static DbContext Context { get; set; } \n");
			sb.Append(" \n");
			sb.Append("        /// <summary> \n");
			sb.Append("        /// 初始化数据库连接 \n");
			sb.Append("        /// </summary> \n");
			sb.Append("        /// <param name=\"schemaName\">连接名称</param> \n");
			sb.Append("        /// <param name=\"connStr\">连接字符串</param> \n");
			sb.Append("        public static void Open(string schemaName,string connStr) \n");
			sb.Append("        { \n");
			sb.Append("            factory = new 基于DbProviderFactory类的数据库工厂(); \n");
			sb.Append("            Context = new DbContext(schemaName, connStr, factory); \n");
			sb.Append("            //是否在执入后执行查询（主要针对Sqlite）\n");
			sb.Append("            Context.IsSupportInsertAfterSelectIdentity = false; \n");
			sb.Append("            //是否在Dispose后执行GC用于解决Dispose后无法删除的问题（主要针对Sqlite）\n");
			sb.Append("            Context.IsSupportGCAfterDispose = true; \n");
			sb.Append("        } \n");
			sb.Append(" \n");
			sb.Append("        public static void Close() \n");
			sb.Append("        { \n");
			sb.Append("            try \n");
			sb.Append("            { \n");
			sb.Append("                //factory.Dispose(); \n");
			sb.Append("            } \n");
			sb.Append("            catch (Exception ex) { } \n");
			sb.Append("            factory = null; \n");
			sb.Append(" \n");
			sb.Append("            try \n");
			sb.Append("            { \n");
			sb.Append("                Context.Dispose(); \n");
			sb.Append("            } \n");
			sb.Append("            catch (Exception ex) { } \n");
			sb.Append("            Context = null; \n");
			sb.Append("        } \n");
			sb.Append("    } \n");
			sb.Append("} \n");
			
			File.WriteAllText(Path.Combine(destClassesPath,"ConnectionManager.cs"),sb.ToString());
		}
		
		/// <summary>
        /// 生成单表代码
        /// </summary>
        /// <param name="dbType">数据库类型</param>
		/// <param name="namespaceStr">命名空间</param>
		/// <param name="classBefore">类名前缀</param>
		/// <param name="classAfter">类名后缀</param>		
        /// <param name="connectionUrl">连接字符串</param>
        /// <param name="tableName">表名</param>
        /// <param name="columns">字段(string[]的长度为2，第一个为字段名称，第二个为字段类型)</param>
        /// <returns>生成后的代码</returns>
        static string makeTable(string dbType,string namespaceStr,string classBefore,string classAfter,string connectionUrl, string tableName, System.Collections.Generic.List<string[]> columns)
        {
			StringBuilder sb = new StringBuilder();
			sb.Append("using System;\n");
			sb.Append("using System.Data;\n");
			sb.Append("using System.Text;\n");
			sb.Append("\n");
			sb.Append("namespace ").Append(namespaceStr).Append(" \n");
			sb.Append("{\n");
			sb.Append("    /// <summary>\n");
			sb.Append("    /// 类").Append(tableName).Append("。\n");
			sb.Append("    /// </summary>\n");
			sb.Append("    [Serializable]\n");
			sb.Append("    public partial class ").Append(classBefore).Append(tableName).Append(classAfter).Append(" : IEntity\n");
			sb.Append("    {\n");
			sb.Append("        public ").Append(classBefore).Append(tableName).Append(classAfter).Append("() { }\n");
			sb.Append("\n");
			sb.Append("        public override Noear.Weed.DbTableQuery copyTo(Noear.Weed.DbTableQuery query)\n");
			sb.Append("        {\n");
			sb.Append("            //设置值\n");
			foreach(string[] cols in columns){
			   sb.Append("            query.set(\"").Append(cols[0]).Append("\", ").Append(cols[0]).Append(");\n");
			}
			
			sb.Append("\n");
			sb.Append("            return query;\n");
			sb.Append("        }\n");
			sb.Append("\n");
			
			foreach(string[] cols in columns){
			   sb.Append("        public ").Append(cols[1].ToLower()).Append(" ").Append(cols[0]).Append(" { get; set; }\n");
			}
			
			sb.Append("\n");
			sb.Append("        public override void bind(Noear.Weed.GetHandlerEx source)\n");
			sb.Append("        {\n");
			
			foreach(string[] cols in columns){
			   sb.Append("            ").Append(cols[0]).Append(" = source(\"").Append(cols[0]).Append("\").value<").Append(cols[1].ToLower()).Append(">(\"\");\n");
			}
			
			sb.Append("        }\n");
			sb.Append("\n");
			sb.Append("        public override Noear.Weed.IBinder clone()\n");
			sb.Append("        {\n");
			sb.Append("            return new ").Append(tableName).Append("();\n");
			sb.Append("        }\n");
			sb.Append("    }\n");
			sb.Append("}\n");
            return sb.ToString();
        }