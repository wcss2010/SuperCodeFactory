        using System.Text;
		using System.IO;
		
		/// <summary>
        /// 生成代码
        /// </summary>
        /// <param name="dbType">数据库类型</param>
		/// <param name="namespaceStr">命名空间</param>
		/// <param name="classBefore">类名前缀</param>
		/// <param name="classAfter">类名后缀</param>		
        /// <param name="connectionUrl">连接字符串</param>
        /// <param name="tableName">表名</param>
        /// <param name="columns">字段(string[]的长度为2，第一个为字段名称，第二个为字段类型)</param>
        /// <returns>生成后的代码</returns>
        string make(string dbType,string namespaceStr,string classBefore,string classAfter,string connectionUrl, string tableName, System.Collections.Generic.List<string[]> columns)
        {
			StringBuilder sb = new StringBuilder();
			
			//生成连接管理器
			sb.Append("using System; \n");
			sb.Append("using System.Collections.Generic; \n");
			sb.Append("using System.Text; \n");
			sb.Append("using Noear.Weed; \n");
			sb.Append(" \n");
			sb.Append("namespace ").Append(namespaceStr).Append(" \n");
			sb.Append("{ \n");
			sb.Append("    public class ConnectionManager \n");
			sb.Append("    { \n");
			sb.Append("        private static System.Data.Common.DbProviderFactory factory = null; \n");
			sb.Append(" \n");
			sb.Append("        /// <summary> \n");
			sb.Append("        /// 数据库上下文 \n");
			sb.Append("        /// </summary> \n");
			sb.Append("        public static DbContext Context { get; set; } \n");
			sb.Append(" \n");
			sb.Append("        /// <summary> \n");
			sb.Append("        /// 初始化数据库连接 \n");
			sb.Append("        /// </summary> \n");
			sb.Append("        /// <param name=\"schemaName\">连接名称</param> \n");
			sb.Append("        /// <param name=\"connStr\">连接字符串</param> \n");
			sb.Append("        public static void Open(string schemaName,string connStr) \n");
			sb.Append("        { \n");
			sb.Append("            factory = new 基于DbProviderFactory类的数据库工厂(); \n");
			sb.Append("            Context = new DbContext(schemaName, connStr, factory); \n");
			sb.Append("            //是否在执入后执行查询（主要针对Sqlite）\n");
			sb.Append("            Context.IsSupportInsertAfterSelectIdentity = false; \n");
			sb.Append("            //是否在Dispose后执行GC用于解决Dispose后无法删除的问题（主要针对Sqlite）\n");
			sb.Append("            Context.IsSupportGCAfterDispose = true; \n");
			sb.Append("        } \n");
			sb.Append(" \n");
			sb.Append("        public static void Close() \n");
			sb.Append("        { \n");
			sb.Append("            try \n");
			sb.Append("            { \n");
			sb.Append("                //factory.Dispose(); \n");
			sb.Append("            } \n");
			sb.Append("            catch (Exception ex) { } \n");
			sb.Append("            factory = null; \n");
			sb.Append(" \n");
			sb.Append("            try \n");
			sb.Append("            { \n");
			sb.Append("                Context.Dispose(); \n");
			sb.Append("            } \n");
			sb.Append("            catch (Exception ex) { } \n");
			sb.Append("            Context = null; \n");
			sb.Append("        } \n");
			sb.Append("    } \n");
			sb.Append("} \n");
			
			sb.Append("\n");
			
			//数据实体抽象类
			sb.Append("using System;\n");
			sb.Append("using System.Collections.Generic;\n");
			sb.Append("using System.Text;\n");
			sb.Append("using Noear.Weed;\n");
			sb.Append("\n");
			sb.Append("namespace ").Append(namespaceStr).Append(" \n");
			sb.Append("{\n");
			sb.Append("    /// <summary>\n");
			sb.Append("    /// 数据实体抽象类\n");
			sb.Append("    /// </summary>\n");
			sb.Append("    public abstract class IEntity : IBinder\n");
			sb.Append("    {\n");
			sb.Append("        /// <summary>\n");
			sb.Append("        /// 将数据复制到\n");
			sb.Append("        /// </summary>\n");
			sb.Append("        /// <param name=\"query\"></param>\n");
			sb.Append("        /// <returns></returns>\n");
			sb.Append("        public abstract Noear.Weed.DbTableQuery copyTo(Noear.Weed.DbTableQuery query);\n");
			sb.Append("\n");
			sb.Append("        /// <summary>\n");
			sb.Append("        /// 数据绑定\n");
			sb.Append("        /// </summary>\n");
			sb.Append("        /// <param name=\"source\"></param>\n");
			sb.Append("        public abstract void bind(GetHandlerEx source);\n");
			sb.Append("\n");
			sb.Append("        public virtual IBinder clone()\n");
			sb.Append("        {\n");
			sb.Append("            return (IBinder)this.MemberwiseClone();\n");
			sb.Append("        }\n");
			sb.Append("    }\n");
			sb.Append("}\n");
			
			sb.Append("\n");
			
			//常用查询语句
			sb.Append("ConnectionManager.Context.table(\"").Append(tableName).Append("\").select(\"*\").getList<").Append(tableName).Append(">(new ").Append(tableName).Append("())").Append("\n");
			sb.Append("ConnectionManager.Context.table(\"").Append(tableName).Append("\").select(\"*\").getItem<").Append(tableName).Append(">(new ").Append(tableName).Append("())").Append("\n");
			sb.Append("ConnectionManager.Context.table(\"").Append(tableName).Append("\").select(\"*\").getDataItem()").Append("\n");
			sb.Append("ConnectionManager.Context.table(\"").Append(tableName).Append("\").select(\"*\").getDataList()").Append("\n");
			
			sb.Append("\n");
			
			//常用查询语句
            foreach(string[] cols in columns)
			{
			    sb.Append("ConnectionManager.Context.table(\"").Append(tableName).Append("\").select(\"").Append(cols[0]).Append("\").getValue<").Append(cols[1].ToLower()).Append(">(").Append(cols[1] == "String" || cols[1]=="string"?"\"\"":"0").Append(")\n");
			}

			sb.Append("\n");
			
			foreach(string[] cols in columns)
			{
				sb.Append("ConnectionManager.Context.table(\"").Append(tableName).Append("\")").Append(".where(\"").Append(cols[0]).Append("=值\")").Append(".select(\"*\").getItem<").Append(tableName).Append(">(new ").Append(tableName).Append("())").Append("\n");
			}

			sb.Append("\n");
		
			foreach(string[] cols in columns)
			{
				sb.Append("ConnectionManager.Context.table(\"").Append(tableName).Append("\")").Append(".where(\"").Append(cols[0]).Append("=值\")").Append(".select(\"*\").getList<").Append(tableName).Append(">(new ").Append(tableName).Append("())").Append("\n");
			}
			
			sb.Append("\n");
			
			foreach(string[] cols in columns)
			{
				sb.Append("ConnectionManager.Context.table(\"").Append(tableName).Append("\").orderBy(\"").Append(cols[0]).Append(" desc").Append("\").where(\"").Append(cols[0]).Append("=值\")").Append(".select(\"*\").getItem<").Append(tableName).Append(">(new ").Append(tableName).Append("())").Append("\n");
			}

			sb.Append("\n");
		
			foreach(string[] cols in columns)
			{
				sb.Append("ConnectionManager.Context.table(\"").Append(tableName).Append("\").orderBy(\"").Append(cols[0]).Append(" desc").Append("\").where(\"").Append(cols[0]).Append("=值\")").Append(".select(\"*\").getList<").Append(tableName).Append(">(new ").Append(tableName).Append("())").Append("\n");
			}
			
			sb.Append("\n");
			
			//常用更新语句
            foreach(string[] cols in columns)
			{
			    sb.Append("类实例.copyTo(ConnectionManager.Context.table(\"").Append(tableName).Append("\")).where(\"").Append(cols[0]).Append("=值\").update();\n");
			}
			
			sb.Append("\n");
			
            //常用插入语句
            foreach(string[] cols in columns)
			{
                sb.Append("类实例.copyTo(ConnectionManager.Context.table(\"").Append(tableName).Append("\")).insert();\n");
			}
			
			sb.Append("\n");
			
			//常用删除语句
            foreach(string[] cols in columns)
			{
			    sb.Append("ConnectionManager.Context.table(\"").Append(tableName).Append("\").where(\"").Append(cols[0]).Append("=值\").delete();\n");
			}
			
			return sb.ToString();
        }